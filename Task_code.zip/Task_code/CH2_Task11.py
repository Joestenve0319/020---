# 如果传入函数s的参数等于1则打印yes，否则打印no
s = lambda x: 'yes' if x==1 else 'no'
# 调用，并传入参数0
print(s(0))
# 调用，并传入参数1
print(s(1))